python generator2.py 1
python generator2.py 2
python generator2.py 3
python generator2.py 4
python generator2.py 5
python generator2.py 6

